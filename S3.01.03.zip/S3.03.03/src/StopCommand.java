
public class StopCommand extends Command{

	
}
