package n3exercici1;

public interface Command {

	public abstract void execute (Vehicle vehicle);

}
