package n3exercici1;

public class Ship extends Vehicle{

	final public String type = "ship";
	
	//CONSTRUCTOR
	public Ship(String number) {
		super(number);
	}
	
	//GETTERS AND SETTERS
	@Override
	public String getVehicleNumber() {
		// TODO Auto-generated method stub
		return super.getVehicleNumber();
	}
	@Override
	public void setVehicleNumber(String vehicleNumber) {
		// TODO Auto-generated method stub
		super.setVehicleNumber(vehicleNumber);
	}
	
	public String getType() {
		return type;
	}
	
}
