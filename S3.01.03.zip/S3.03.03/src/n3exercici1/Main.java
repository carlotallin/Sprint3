package n3exercici1;

public class Main {

	public static void main(String[] args) {
        
        SuperCommand superCommand= new SuperCommand();
         
        superCommand.addCommand(new StartCommand());
        superCommand.addCommand(new StopCommand());
        superCommand.addCommand(new AccelerateCommand());

        CommandManager cm = new CommandManager();
        Car vehicle1 = new Car("965413LBC");
        Plane vehicle2 = new Plane("963578OPD");
        Ship vehicle3 = new Ship("841265JKC");
        Bike vehicle4 = new Bike("5269KC");

        cm.execute(superCommand, vehicle1);
        cm.execute(superCommand, vehicle2);
        cm.execute(superCommand, vehicle3);
        cm.execute(superCommand, vehicle4);
         
    }
 }
