package n3exercici1;

public class AccelerateCommand implements Command{

	@Override
	public void execute(Vehicle vehicle) {
		System.out.println("The vehicle with " + vehicle.getVehicleNumber() + " number is accelerating.");
	}
	
	
}
