package n3exercici1;

public class StartCommand implements Command{

	@Override
	public void execute(Vehicle vehicle) {
		System.out.println("The vehicle with " + vehicle.getVehicleNumber() + " number has started off.");
	}
	
	
}
