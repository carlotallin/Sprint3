package n3exercici1;

public class CommandManager {

	public void execute (Command command, Vehicle vehicle) {
		command.execute(vehicle);
	}
}
