package n3exercici1;

public class StopCommand implements Command{

	@Override
	public void execute(Vehicle vehicle) {
		System.out.println("The vehicle with " + vehicle.getVehicleNumber() + " number has stopped.");
	}
	
	
}
