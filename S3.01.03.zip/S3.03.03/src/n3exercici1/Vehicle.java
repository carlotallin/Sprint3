package n3exercici1;

public class Vehicle {

	//FIELDS
	String vehicleNumber;
	
	//CONSTRUCTOR
	public Vehicle (String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}
	
	//GETTERS AND SETTERS
	public String getVehicleNumber() {
		return vehicleNumber;
	}	
	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}

	
	
}
