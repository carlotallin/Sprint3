
public abstract class Command {

	
}
