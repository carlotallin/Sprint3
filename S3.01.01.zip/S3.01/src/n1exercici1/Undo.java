package n1exercici1;

import java.util.ArrayList;

public class Undo {

	//Atributes
	private static Undo instancia;
	private static ArrayList<String> listItems; 

	//Constructor. To avoid the instance only through operator "new" private	
	private Undo() {
		listItems = new ArrayList<>();
	}
	
	//Getters
	//Get Instance. To obtain the instance only through this method
	public static Undo getInstanciaUndo() {
		if (instancia == null) {
			instancia = new Undo();
		}
		return instancia;
	}
		
	public static ArrayList<String> getListItems() {
		return listItems;
	}	
	
	//Setter
	public static void setInstancia(Undo instancia) {
		Undo.instancia = instancia;
	}
	
	public static void setListItems(ArrayList<String> listItems) {
		Undo.listItems = listItems;
	}
	
	//Method 1. Add
	public void addItem(String answer) {
		listItems.add(answer);
		System.out.println( "\n * Item: '" + answer + "' has been added to the list *");
	}
	
	//Method 2. Remove
	public void removeItem(String answer) {
		if (listItems.contains(answer)) {
			listItems.remove(answer);
			System.out.println( "\n * Item: '" + answer + "' has been removed from the list *");
		}
		else {System.out.println("\n * This item it's not in the list. *");}
	}
	
	//Method 3. Print
	public void printItems () {
		if(listItems.isEmpty()) 
			{System.out.println("\n * There are no items in the list yet*");
		}
		//Print List in DESC order, first the newer items.
		else { System.out.println("\n * Actual list *");
			for (int i = (listItems.size()-1); i>=0; i--)
				{System.out.println(listItems.get(i));
				System.out.println("\n");
			}
		}
	}
}
	

