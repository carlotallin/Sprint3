package n1exercici1;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
	
	public static void main(String[]args) {
		
		menu();
		
	}
	
	public static void menu() {
		
		
		int answerMenu = 0;
		Scanner sc = new Scanner (System.in); 
		
		do {
			System.out.println("\n- Menu -" + 
				"\n 1. Add element" + 
				"\n 2. Remove element" + 
				"\n 3. Print list" + 
				"\n 4. Exit" +
				"\n\n\nSelect option: ");
			answerMenu = sc.nextInt();

			switch (answerMenu) {
				case 1:	addQuestion();
						break;
				case 2: removeQuestion();
						break;
				case 3: printItemQuestion();
						break;
				case 4: System.out.println("\n** You have exited the site **");
						System.exit(0);	
			}
				
			if 	(answerMenu > 4) 
			{System.out.println("\n ** Please write a valid number ** ");}	
		} 
		while (answerMenu !=4);	
		
		sc.close();
	} 
			
	public static void addQuestion() {	
		Scanner sc = new Scanner (System.in);
		System.out.println("Write the Item you want to add:");
		String answer = sc.nextLine();
		Undo.getInstanciaUndo().addItem(answer);	
	}
	
	public static void removeQuestion() {	
		Scanner sc = new Scanner (System.in);
		System.out.println("Write the Item you want to erase:");
		String answer3 = sc.nextLine();
		Undo.getInstanciaUndo().removeItem(answer3);	
	}
	
	public static void printItemQuestion() {
		Undo.getInstanciaUndo().printItems();
	}
}

