package n1exercici1;

public interface Observable {
	
	public void attachObersever (StockAgency o);
	public void detachObersever (StockAgency o);
	public void notifyIncrement ();
	public void notifyDecrement ();
	
}
