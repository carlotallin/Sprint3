package n1exercici1;

public class StockAgency implements Observer{
	
	//FIELDS
	private String name;
	private StockAgent o;

	//CONSTRUCTOR
	public StockAgency(String name) {
		this.name = name;
	}
	
	//GETTERS AND SETTERS
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public StockAgent getO() {
		return o;
	}
	public void setO(StockAgent o) {
		this.o = o;
	}
	
	//METHODS
	public void subscribeTo (StockAgent o) {
		this.o = o;	
		System.out.println(name + " is subscribed to '" + o.getObservableName() + "'.");
	}
	
	public void unsubscribeTo (StockAgent o) {
		this.o = o;	
		System.out.println(name + " is now unsubscribed from '" + o.getObservableName() + "'.");
	}
	
	public void updateIncrement() {
		System.out.println( "** " + name + ", there has been an increment **");
	}
	
	public void updateDecrement() {
		System.out.println("** " + name + ", there has been a decrement **");
	}

}
