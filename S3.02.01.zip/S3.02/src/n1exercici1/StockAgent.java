package n1exercici1;

import java.util.ArrayList;

public class StockAgent implements Observable{

	//FIELDS
	private String observableName;
	private ArrayList<StockAgency> observersList; 
	
	// CONSTRUCTOR
	public StockAgent(String observableName) {
		this.observableName = observableName;
		observersList = new ArrayList<StockAgency>();
	}
	
	//GETTERS AND SETTERS
	public ArrayList<StockAgency> getObserversList() {
		return observersList;
	}
	public String getObservableName() {
		return observableName;
	}
	public void setObserversList(ArrayList<StockAgency> observersList) {
		this.observersList = observersList;
	}
	public void setObservableName(String observableName) {
	this.observableName = observableName;
}	
	
	//METHODS
	public void attachObersever (StockAgency o) {
		observersList.add(o);
		System.out.println(observableName + " has a new subscriber: '" + o.getName() + "'.");

	}	

	public void detachObersever (StockAgency o) {
		observersList.remove(o);
		System.out.println(observableName + " has lost a subscriber: '" + o.getName() + "'.");

	}

	public void notifyIncrement () {
		for (StockAgency o : observersList)
			{
				o.updateIncrement();
			}
	}
	
	public void notifyDecrement () {
		for (StockAgency o : observersList)
			{
				o.updateDecrement();
			}		
	}
}
