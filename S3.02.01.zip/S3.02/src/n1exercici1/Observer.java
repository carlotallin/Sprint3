package n1exercici1;

public interface Observer {

	public void subscribeTo (StockAgent o);
	public void unsubscribeTo (StockAgent o);
	public void updateIncrement();
	public void updateDecrement();
	
}
