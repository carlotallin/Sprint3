package n1exercici1;

public class Main {

	//Dissenya un sistema en el qual un Agent de Borsa 
	//(Observable) notifica a diverses agències de Borsa (Observers) canvis quan la Borsa puja o baixa.
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Instance objects
		Observable borsaAgente = new Observable("Borsa Agente"); 
	
		Observer borsaAgencia1 = new Observer("Agencia 1");
		Observer borsaAgencia2 = new Observer("Agencia 2");
		Observer borsaAgencia3 = new Observer("Agencia 3");

		//Attach Observer to an Observable
		borsaAgente.attachObersever(borsaAgencia1);
		borsaAgente.attachObersever(borsaAgencia2);
		borsaAgente.attachObersever(borsaAgencia3);
		System.out.println("\n");

		//Attach Observable to an Observer
		borsaAgencia1.subscribeTo(borsaAgente);
		borsaAgencia2.subscribeTo(borsaAgente);
		borsaAgencia3.subscribeTo(borsaAgente);
		System.out.println("\n");

		//Detach
		borsaAgente.detachObersever(borsaAgencia3);
		borsaAgencia3.unsubscribeTo(borsaAgente);
		System.out.println("\n");

		//Notify
		borsaAgente.notifyIncrement();
		System.out.println("\n");
		borsaAgente.notifyDecrement();
	}
}
