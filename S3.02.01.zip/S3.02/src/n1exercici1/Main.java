package n1exercici1;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Instance objects
		StockAgent borsaAgente = new StockAgent("Borsa Agente"); 
	
		StockAgency borsaAgencia1 = new StockAgency("Agencia 1");
		StockAgency borsaAgencia2 = new StockAgency("Agencia 2");
		StockAgency borsaAgencia3 = new StockAgency("Agencia 3");

		//Attach Observer to an Observable
		borsaAgente.attachObersever(borsaAgencia1);
		borsaAgente.attachObersever(borsaAgencia2);
		borsaAgente.attachObersever(borsaAgencia3);
		System.out.println("\n");

		//Attach Observable to an Observer
		borsaAgencia1.subscribeTo(borsaAgente);
		borsaAgencia2.subscribeTo(borsaAgente);
		borsaAgencia3.subscribeTo(borsaAgente);
		System.out.println("\n");

		//Detach
		borsaAgente.detachObersever(borsaAgencia3);
		borsaAgencia3.unsubscribeTo(borsaAgente);
		System.out.println("\n");

		//Notify
		borsaAgente.notifyIncrement();
		System.out.println("\n");
		borsaAgente.notifyDecrement();
	}
}
