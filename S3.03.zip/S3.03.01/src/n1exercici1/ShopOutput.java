package n1exercici1;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class ShopOutput {

	private FileOutputStream file;
	private ObjectOutputStream output;
	
	public void open() throws IOException {
		file = new FileOutputStream("shops.ser");
		output = new ObjectOutputStream(file);
	}
	
	public void close() throws IOException {
		if (output != null)
			output.close();
	}
	
	public void write (ArrayList<FlowerShop> shop) throws IOException {
		if (output!=null) {
			output.writeObject(shop);
		}
	}
}
