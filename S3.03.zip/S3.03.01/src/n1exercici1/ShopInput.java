package n1exercici1;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class ShopInput {

	private  FileInputStream file;
	private ObjectInputStream input;
	
	public void open() throws IOException {
		file = new FileInputStream("shops.ser");
		input = new ObjectInputStream(file);
	}
	
	public void close() throws IOException {
		if (input != null)
			input.close();
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList<FlowerShop> read () throws IOException {
		ArrayList<FlowerShop> shops = new ArrayList<>();
		if (input!= null) {
			try {
				shops = (ArrayList<FlowerShop>) input.readObject();
			} catch (Exception e) {
				System.out.println("\n*** ERROR. DATABASE COULDN'T BE READ ***");
			}
		}
		return shops;
	}
	
}

