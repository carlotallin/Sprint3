package n1exercici1;

import java.io.Serializable;

public class Decoration extends Product implements Serializable {

	//FIELDS
	protected final String type;
	
	//GETTER
	public String getType() {
		return type;
	}
	
	//CONSTRUCTOR
	public Decoration(int id, double price) {
		super(id, price);
		this.type= "Decoration";
	}
	
	//TO STRING
	@Override
	public String toString() {
		return "\nType: " + type
				+ "\nId: " + getIdProduct() 
				+ "\nPrice: " + getPrice();
	}
}
