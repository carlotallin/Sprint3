package n1exercici1;

public class Deserealize {

}
