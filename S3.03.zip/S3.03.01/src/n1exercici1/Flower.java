package n1exercici1;

import java.io.Serializable;

public class Flower extends Product implements Serializable {

	//FIELDS
	private final String type;
	private String color;

	//CONSTRUCTOR
	public Flower(int id, double price, String color) {
		super(id, price);
		this.type = "Flower";
		this.color = color;
	}
	
	//GETTERS
	public String getType() {
		return type;
	}
	public String getColor() {
		return color;
	}
	
	//SETTERS
	public void setColor(String color) {
		this.color = color;
	}

	//TO STRING
	@Override
	public String toString() {	
		return "\nType: " + type
				+ "\nId: " + getIdProduct() 
				+ "\nPrice: " + getPrice()
				+ "\nColor: " + color;	
	}
}
