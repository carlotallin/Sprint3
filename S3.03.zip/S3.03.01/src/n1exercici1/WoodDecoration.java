package n1exercici1;

import java.io.Serializable;

public class WoodDecoration extends Decoration implements Serializable{

	//FIELDS
	private final String material;
	
	//CONSTRUCTOR
	public WoodDecoration(int id, double price) {
		super(id, price);
		material = "Wood";
	}

	//GETTERS 
	public String getMaterial() {
		return material;
	}
	
	//TO STRING
	@Override
	public String toString() {	
		return "\nType: " + getType()
				+ "\nId: " + getIdProduct() 
				+ "\nPrice: " + getPrice()
				+ "\nMaterial: " + material;	
	}
}
