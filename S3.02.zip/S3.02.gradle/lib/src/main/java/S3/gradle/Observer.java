package S3.gradle;

public class Observer {
	
	//FIELDS
	private String name;
	private Observable o;

	//CONSTRUCTOR
	public Observer(String name) {
		this.name = name;
	}
	
	//GETTERS AND SETTERS
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Observable getO() {
		return o;
	}
	public void setO(Observable o) {
		this.o = o;
	}
	
	//METHODS
	public void subscribeTo (Observable o) {
		this.o = o;	
		System.out.println(name + " is subscribed to '" + o.getObservableName() + "'.");
	}
	
	public void unsubscribeTo (Observable o) {
		this.o = o;	
		System.out.println(name + " is now unsubscribed from '" + o.getObservableName() + "'.");
	}
	
	public void updateIncrement() {
		System.out.println( "** " + name + ", there has been an increment **");
	}
	
	public void updateDecrement() {
		System.out.println("** " + name + ", there has been a decrement **");
	}


}
