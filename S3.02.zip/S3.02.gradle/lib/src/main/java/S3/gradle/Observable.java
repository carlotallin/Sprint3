package S3.gradle;

import java.util.ArrayList;

public class Observable {

	//FIELDS
	private String observableName;
	private ArrayList<Observer> observersList; 
	
	// CONSTRUCTOR
	public Observable(String observableName) {
		this.observableName = observableName;
		observersList = new ArrayList<Observer>();
	}
	
	//GETTERS AND SETTERS
	public ArrayList<Observer> getObserversList() {
		return observersList;
	}
	public String getObservableName() {
		return observableName;
	}
	public void setObserversList(ArrayList<Observer> observersList) {
		this.observersList = observersList;
	}
	public void setObservableName(String observableName) {
	this.observableName = observableName;
}	
	
	//METHODS
	public void attachObersever (Observer o) {
		observersList.add(o);
		System.out.println(observableName + " has a new subscriber: '" + o.getName() + "'.");

	}	

	public void detachObersever (Observer o) {
		observersList.remove(o);
		System.out.println(observableName + " has lost a subscriber: '" + o.getName() + "'.");

	}

	public void notifyIncrement () {
		for (Observer o : observersList)
			{
				o.updateIncrement();
			}
	}
	
	public void notifyDecrement () {
		for (Observer o : observersList)
			{
				o.updateDecrement();
			}		
	}
}
